CREATE VIEW `sales by category` AS
  SELECT
    `northwind`.`categories`.`CategoryID`         AS `CategoryID`,
    `northwind`.`categories`.`CategoryName`       AS `CategoryName`,
    `northwind`.`products`.`ProductName`          AS `ProductName`,
    sum(`order details extended`.`ExtendedPrice`) AS `ProductSales`
  FROM (((`northwind`.`categories`
    JOIN `northwind`.`products` ON ((`northwind`.`categories`.`CategoryID` = `northwind`.`products`.`CategoryID`))) JOIN
    `northwind`.`order details extended`
      ON ((`northwind`.`products`.`ProductID` = `order details extended`.`ProductID`))) JOIN `northwind`.`orders`
      ON ((`northwind`.`orders`.`OrderID` = `order details extended`.`OrderID`)))
  WHERE (`northwind`.`orders`.`OrderDate` BETWEEN '1997-01-01' AND '1997-12-31')
  GROUP BY `northwind`.`categories`.`CategoryID`, `northwind`.`categories`.`CategoryName`,
    `northwind`.`products`.`ProductName`;
