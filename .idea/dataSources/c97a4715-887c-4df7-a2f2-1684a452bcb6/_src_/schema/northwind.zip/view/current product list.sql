CREATE VIEW `current product list` AS
  SELECT
    `northwind`.`products`.`ProductID`   AS `ProductID`,
    `northwind`.`products`.`ProductName` AS `ProductName`
  FROM `northwind`.`products`
  WHERE (`northwind`.`products`.`Discontinued` = 0);
