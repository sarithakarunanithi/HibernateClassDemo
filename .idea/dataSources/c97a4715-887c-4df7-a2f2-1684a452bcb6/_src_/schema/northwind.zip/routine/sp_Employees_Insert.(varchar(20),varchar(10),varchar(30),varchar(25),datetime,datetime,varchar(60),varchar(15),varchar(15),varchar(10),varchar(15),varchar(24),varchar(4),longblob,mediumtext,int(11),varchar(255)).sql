CREATE PROCEDURE sp_Employees_Insert(IN  AtLastName        VARCHAR(20), IN AtFirstName VARCHAR(10),
                                     IN  AtTitle           VARCHAR(30), IN AtTitleOfCourtesy VARCHAR(25),
                                     IN  AtBirthDate       DATETIME, IN AtHireDate DATETIME, IN AtAddress VARCHAR(60),
                                     IN  AtCity            VARCHAR(15), IN AtRegion VARCHAR(15),
                                     IN  AtPostalCode      VARCHAR(10), IN AtCountry VARCHAR(15),
                                     IN  AtHomePhone       VARCHAR(24), IN AtExtension VARCHAR(4), IN AtPhoto LONGBLOB,
                                     IN  AtNotes           MEDIUMTEXT, IN AtReportsTo INT, IN AtPhotoPath VARCHAR(255),
                                     OUT AtReturnID        INT)
  BEGIN
Insert Into Employees Values(AtLastName,AtFirstName,AtTitle,AtTitleOfCourtesy,AtBirthDate,AtHireDate,AtAddress,AtCity,AtRegion,AtPostalCode,AtCountry,AtHomePhone,AtExtension,AtPhoto,AtNotes,AtReportsTo,AtPhotoPath);

	SELECT AtReturnID = LAST_INSERT_ID();
	
END;
