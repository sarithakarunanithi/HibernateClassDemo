CREATE PROCEDURE LookByFName(IN AtFirstLetter CHAR)
  BEGIN
     SELECT * FROM Employees  Where LEFT(FirstName, 1)=AtFirstLetter;

END;
